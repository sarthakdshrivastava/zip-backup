import com.seed.beans.ShoppingCart;

public class abc {
	void abcd(){
		ShoppingCart cart;
	}
}
