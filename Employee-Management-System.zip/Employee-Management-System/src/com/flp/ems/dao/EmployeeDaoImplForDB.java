package com.flp.ems.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.flp.ems.domain.Employee;

public class EmployeeDaoImplForDB implements IEmployeeDao {
	Properties props;
	public EmployeeDaoImplForDB(){
		props=new Properties();
		FileInputStream fileInputStream=null;
		try {
			fileInputStream=new FileInputStream("dbDetails.properties");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		try {
			props.load(fileInputStream);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	private Connection createConnection(){
		String url=props.getProperty("jdbc.url");
		Connection connection=null;
		try {
			connection=DriverManager.getConnection(url);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return connection;
	}
	@Override
	public void addEmployee(Employee employee) {
		Connection connection=createConnection();
		String insertQuery=props.getProperty("jdbc.query.insert");
		try(PreparedStatement insertStatement=connection.prepareStatement(insertQuery,PreparedStatement.RETURN_GENERATED_KEYS)){
			insertStatement.setString(1, employee.getName());
			insertStatement.setString(2, "dummy");
			insertStatement.setLong(3, employee.getPhoneNumber());
			insertStatement.setDate(4, new java.sql.Date(employee.getDateOfBirth().getTime()));
			insertStatement.setDate(5, new java.sql.Date(employee.getDateOfJoining().getTime()));
			insertStatement.setString(6, employee.getAddress());
			insertStatement.setInt(7,employee.getDepartmentId());
			insertStatement.setInt(8, employee.getProjectId());
			insertStatement.setInt(9, employee.getRoleId());
			insertStatement.execute();
			ResultSet rs=insertStatement.getGeneratedKeys();
			rs.next();
			employee.setId(rs.getLong(1));
		}
		catch(Exception e){
			e.printStackTrace();
		}
		String addEmailQuery=props.getProperty("jdbc.query.addEmail");
		try(PreparedStatement addEmailStatement=connection.prepareStatement(addEmailQuery)){
			addEmailStatement.setString(1, employee.getName()+employee.getId()+"@barclaycard.co.uk");
			addEmailStatement.setString(2, "dummy");
			addEmailStatement.executeUpdate();
		}
		catch(Exception e){
			e.printStackTrace();
		}		
	}

	@Override
	public void modifyEmployee(Employee employee) {
		
	}

	@Override
	public boolean removeEmployee(long id) {
		return false;
	}

	@Override
	public List<Employee> searchEmployee(Map<String, String> map) {
		return null;
	}

	@Override
	public List<Employee> getAllEmployee() {
		return null;
	}

}
