package com.flp.ems.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.flp.ems.domain.Employee;

public class EmployeeDaoImplForDB implements IEmployeeDao {
	Properties props;
	public EmployeeDaoImplForDB(){
		props=new Properties();
		FileInputStream fileInputStream=null;
		try {
			fileInputStream=new FileInputStream("dbDetails.properties");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		try {
			props.load(fileInputStream);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	private Connection createConnection(){
		String url=props.getProperty("jdbc.url");
		Connection connection=null;
		try {
			connection=DriverManager.getConnection(url);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return connection;
	}
	@Override
	public void addEmployee(Employee employee) {
		Connection connection=createConnection();
		String insertQuery=props.getProperty("jdbc.query.insert");
		try(PreparedStatement insertStatement=connection.prepareStatement(insertQuery)){
			
		}
		catch(Exception e){
			
		}
	}

	@Override
	public void modifyEmployee(Employee employee) {
		
	}

	@Override
	public boolean removeEmployee(long id) {
		return false;
	}

	@Override
	public List<Employee> searchEmployee(Map<String, String> map) {
		return null;
	}

	@Override
	public List<Employee> getAllEmployee() {
		return null;
	}

}
