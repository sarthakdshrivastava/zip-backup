package com.cg;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository
public class UserDao {

	private DataSource dataSource;
	
	public DataSource getDataSource() {
		return dataSource;
	}
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public void addUser(UserDTO userDTO){
		Connection con = null;
		try {
			con=(Connection) dataSource.getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		String query="insert into Users values(?,?,?,?,?)";
		try(PreparedStatement insertStatement=con.prepareStatement(query)){
			insertStatement.setString(1, userDTO.getUsername());
			insertStatement.setString(2, userDTO.getPassword());
			insertStatement.setString(3, userDTO.getEmail());
			insertStatement.setDate(4, new java.sql.Date(userDTO.getBirthDate().getTime()));
			insertStatement.setString(5, userDTO.getProfession());
			insertStatement.execute();
			con.commit();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
